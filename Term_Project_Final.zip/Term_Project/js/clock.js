
/*
  This program creates a clock and date that is displayes on the welcome tab
  Authors: Aliza Buchen and Avigayil Imani
  Date: 12/3/2022
 */
runClock();
setInterval("runClock()",1000);
function runClock() {

    /* store current date and time*/
    var currentDay = new Date();
    var dateStr = currentDay.toLocaleDateString();
    var timeStr = currentDay.toLocaleTimeString();

    /* Display the current date and time */
    document.getElementById("dateNow").innerHTML = dateStr + "<br />" + timeStr;
}