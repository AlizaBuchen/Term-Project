/*
  This program notifies the user if the form was successfully completed.
  Authors: Aliza Buchen and Avigayil Imani
  Date: 12/4/2022
 */
window.onload = function() {
   document.forms[0].onsubmit = function() {
      if (this.checkValidity()) alert("Success!");
      return true;
   };
};